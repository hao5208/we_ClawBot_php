<?php
return [
    'base_url' => 'https://ilinkai.weixin.qq.com',
    'channel_version' => '1.0.2',
    'token_file' => __DIR__ . '/token.json',
    'log_file' => __DIR__ . '/bot.log',
    'session_file' => __DIR__ . '/session.json'
];
