<?php
$config = require __DIR__ . '/config.php';

function logMsg($msg){
    global $config;
    file_put_contents($config['log_file'],
        "[".date("Y-m-d H:i:s")."] ".$msg.PHP_EOL, FILE_APPEND);
}

function randomUin(){
    return base64_encode((string)random_int(100000,999999999));
}

function headers($token='', $body=''){
    $h=[
        "Content-Type: application/json",
        "AuthorizationType: ilink_bot_token",
        "X-WECHAT-UIN: ".randomUin(),
    ];
    if($token) $h[]="Authorization: Bearer ".$token;
    if($body) $h[]="Content-Length: ".strlen($body);
    return $h;
}

function apiPost($ep,$data=[],$token=''){
    global $config;
    $url=rtrim($config['base_url'],'/').'/'.$ep;
    $body=json_encode($data);

    $ch=curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_POST=>true,
        CURLOPT_HTTPHEADER=>headers($token,$body),
        CURLOPT_POSTFIELDS=>$body,
        CURLOPT_TIMEOUT=>15
    ]);
    $res=curl_exec($ch);
    curl_close($ch);

    logMsg("API $ep => ".$res);
    return json_decode($res,true);
}

function saveToken($d){
    global $config;
    file_put_contents($config['token_file'],json_encode($d));
}

function loadToken(){
    global $config;
    if(!file_exists($config['token_file'])) return null;
    return json_decode(file_get_contents($config['token_file']),true);
}
