<?php
require 'common.php';
$config=require 'config.php';

$t=loadToken()['bot_token'];
$cursor='';

while(true){
    $r=apiPost("ilink/bot/getupdates",[
        "get_updates_buf"=>$cursor,
        "base_info"=>["channel_version"=>"1.0.2"]
    ],$t);

    if(!empty($r['get_updates_buf'])) $cursor=$r['get_updates_buf'];

    foreach($r['msgs']??[] as $m){
        if($m['message_type']==2) continue;

        $text='';
        foreach($m['item_list'] as $i){
            if($i['type']==1) $text.=$i['text_item']['text'];
        }

        $from=$m['from_user_id'];
        $context=$m['context_token'];

        file_put_contents($config['session_file'],json_encode([
            "to"=>$from,"context"=>$context
        ]));

        logMsg("收到: $from => $text");

        file_get_contents("http://bot.cn/aa.php?msg=".urlencode($text));
    }
}
