<?php
require 'common.php';
$config=require 'config.php';

echo "扫码登录\n";
$data=json_decode(file_get_contents($config['base_url']."/ilink/bot/get_bot_qrcode?bot_type=3"),true);

echo "打开链接扫码:\n".$data['qrcode_img_content']."\n";

$q=$data['qrcode'];

while(true){
    sleep(2);
    $s=json_decode(file_get_contents($config['base_url']."/ilink/bot/get_qrcode_status?qrcode=".urlencode($q)),true);
    echo "等待扫码...\n";
    if(!empty($s['bot_token'])){
        saveToken($s);
        echo "登录成功\n";
        break;
    }
}
