<?php
require 'common.php';
$config=require 'config.php';

$session=json_decode(file_get_contents($config['session_file']),true);
$to=$_GET['to']??$session['to']??'';
$context=$_GET['context']??$session['context']??'';
$msg=$_GET['msg']??'';
$type=$_GET['type']??'text';

$t=loadToken()['bot_token'];

function send($body,$t){
    return apiPost("ilink/bot/sendmessage",$body,$t);
}

if($type=='image'){
    $body=[
        "msg"=>[
            "to_user_id"=>$to,
            "client_id"=>uniqid(),
            "message_type"=>2,
            "message_state"=>2,
            "context_token"=>$context,
            "item_list"=>[[
                "type"=>3,
                "image_item"=>["image_url"=>$msg]
            ]]
        ],
        "base_info"=>["channel_version"=>"1.0.2"]
    ];
}else{
    $body=[
        "msg"=>[
            "to_user_id"=>$to,
            "client_id"=>uniqid(),
            "message_type"=>2,
            "message_state"=>2,
            "context_token"=>$context,
            "item_list"=>[[
                "type"=>1,
                "text_item"=>["text"=>$msg]
            ]]
        ],
        "base_info"=>["channel_version"=>"1.0.2"]
    ];
}

//print_r(send($body,$t));








echo json_encode([
    "status" => "ok",
    "api_result" => send($body,$t)
], JSON_UNESCAPED_UNICODE);