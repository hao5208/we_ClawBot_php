<?php
require 'common.php';
$msg=$_GET['msg']??'';

logMsg("回调: ".$msg);

file_get_contents("http://bot.cn/send.php?msg=".urlencode("自动回复: ".$msg));
