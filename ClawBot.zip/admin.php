<?php
echo '<h2>发送消息</h2>';
echo '<form>';
echo '<input name=msg placeholder=消息>';
echo '<select name=type><option value=text>文本</option><option value=image>图片</option></select>';
echo '<button>发送</button>';
echo '</form>';

if(isset($_GET['msg'])){
    echo file_get_contents("send.php?msg=".urlencode($_GET['msg'])."&type=".$_GET['type']);
}
